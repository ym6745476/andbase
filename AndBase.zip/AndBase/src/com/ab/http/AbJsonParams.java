package com.ab.http;


public abstract class AbJsonParams {
	
	public abstract String getJson();

}
